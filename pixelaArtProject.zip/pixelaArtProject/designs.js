
 //Declartion of varibles
const sizeGrid = document.getElementById("sizePicker");
const Hieght = document.getElementById('inputHeight');
const Width = document.getElementById("inputWidth");
const colorOfCell = document.getElementById('colorPicker');
const Canvas = document.getElementById('pixelCanvas');
//MakeGrid() function is responsible for making the grid by taking the input of the height and width
function makeGrid() {
  Canvas.innerHTML = ""; //Here we make the table empty in order to create the new table with new dimintions
  for (let r = 0; r < Hieght.value; r++) {
    const row = document.createElement("TR"); //create a row
    Canvas.appendChild(row); //add the row to the table
    for (let c = 0; c < Width.value; c++) {
      row.insertCell(0); //insert cells in the row
    }
  }
}
//This function is used to delete the rows of the previous table without deleting the table
function chooseColor(e) {
  if (e.target.nodeName === "TD") { // We are making a condtion to color a the clicked cell
    e.target.style.backgroundColor = colorOfCell.value;
  }
}

function clearColor(e) {
  if (e.target.nodeName === "TD") {
    e.target.style.backgroundColor = '#FFFFFF';
  }
}
sizeGrid.addEventListener('submit', function(e) { //This is to change the size of the grid
  Canvas.style.backgroundColor = '#FFFFFF'; //Turn the Grid to white 
  e.preventDefault();
  makeGrid(); //Make the pixel canvas  
});

Canvas.addEventListener('click', function(e) { //This is to color the cells with the selected color
  chooseColor(e);
});

Canvas.addEventListener('dblclick', function(e) { //This is to uncolor the cells 
  clearColor(e);
});